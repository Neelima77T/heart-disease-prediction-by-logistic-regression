
import streamlit as st
import pandas as pd
import joblib

# Load model
model = joblib.load("heart_model.pkl")

st.title("💓 Heart Disease Prediction App")

# Input fields
age = st.number_input("Age", 20, 100)
sex = st.selectbox("Sex", [0, 1])  # 0 = female, 1 = male
cp = st.selectbox("Chest Pain Type (0-3)", [0, 1, 2, 3])
trestbps = st.number_input("Resting Blood Pressure", 80, 200)
chol = st.number_input("Cholesterol", 100, 400)
fbs = st.selectbox("Fasting Blood Sugar > 120", [0, 1])
restecg = st.selectbox("Resting ECG (0-2)", [0, 1, 2])
thalach = st.number_input("Max Heart Rate Achieved", 70, 210)
exang = st.selectbox("Exercise-induced Angina", [0, 1])
oldpeak = st.number_input("ST Depression", 0.0, 6.0, step=0.1)
slope = st.selectbox("Slope (0-2)", [0, 1, 2])
ca = st.selectbox("Number of Major Vessels (0-3)", [0, 1, 2, 3])
thal = st.selectbox("Thalassemia (1 = normal, 2 = fixed defect, 3 = reversible defect)", [1, 2, 3])

# Prediction
if st.button("Predict"):
    features = [[age, sex, cp, trestbps, chol, fbs, restecg, thalach,
                 exang, oldpeak, slope, ca, thal]]
    prediction = model.predict(features)

    if prediction[0] == 1:
        st.error("⚠️ High Risk of Heart Disease")
    else:
        st.success("✅ Low Risk of Heart Disease")
